/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   NodoGen.h
 * Author: Enzo
 *
 * Created on 30 de mayo de 2024, 05:22 PM
 */

#ifndef NODOGEN_H
#define NODOGEN_H

struct NodoGen{
    char servidor;
    int velocidad;
    int nivel;
};

#endif /* NODOGEN_H */


/* 
 * File:   main.cpp
 * Author: Flavio
 * Created on 29 de mayo de 2024, 04:31 PM
 */

#include <iomanip>
#include <iostream>
#include<fstream>

#include "ArbolBinarioBusqueda.h"
#include "funcionesArbolesBB.h"

using namespace std;

void    insertarDatosEnArbolBB(NodoArbol*&nodo,int fecha,int stock){
    if(nodo==nullptr){
        NodoArbol*nuevoNodo=new NodoArbol;
        nuevoNodo->derecha=nullptr;
        nuevoNodo->izquierda=nullptr;
        nuevoNodo->elemento=fecha;
        nuevoNodo->stock=stock;
        nodo=nuevoNodo;
    }else{
        if(nodo->elemento<fecha){
            insertarDatosEnArbolBB(nodo->izquierda,fecha,stock);
        }else if(nodo->elemento>fecha){
            insertarDatosEnArbolBB(nodo->derecha,fecha,stock);
        }else{
            nodo->stock+=stock;
        }
    }
}
void    imprimeEnOrdenBB(NodoArbol*nodo){
    if(nodo!=nullptr){
         imprimeEnOrdenBB(nodo->derecha);
         cout<<'['<<nodo->elemento<<'-'<<nodo->stock<<']'<<"  ";
         imprimeEnOrdenBB(nodo->izquierda);
    }
}
int    calculaNodosEnArbol(NodoArbol*nodo){
    if(nodo==nullptr){
        return 0;
    }else{
        //si hay algun elemento
        return 1+calculaNodosEnArbol(nodo->derecha)+calculaNodosEnArbol(nodo->izquierda);
    }
}
int altura(struct NodoArbol* nodo){
    if(nodo==nullptr){
        return 0;
    }if(nodo->derecha==nullptr and nodo->izquierda==nullptr){
        return 0;
    }else{
        return 1+altura(nodo->derecha)+altura(nodo->izquierda);
    }
}
void RecorridoAmplitudRecursivoSinCola(struct NodoArbol* nodo,struct NodoArbol* &raiz, int nivel) {
    if (nodo == nullptr)
        return;
    if (nivel == 0)
        //AQUI PASARA NODO POR NODO
        insertarDatosEnArbolBB(raiz,nodo->elemento,nodo->stock);
//        cout<<'['<<nodo->elemento<<'-'<<nodo->stock<<']'<<"  ";
    else if (nivel > 0) {
        RecorridoAmplitudRecursivoSinCola(nodo->izquierda,raiz, nivel - 1);
        RecorridoAmplitudRecursivoSinCola(nodo->derecha,raiz, nivel - 1);
    }
}
void RecorridoAmplitudRecursivoSinCola(struct ArbolBinario &destino,struct ArbolBinario &emisor) {
    int alto = altura(emisor.raiz);
    cout << "Recorrer desde la raiz hasta las hojas:" << endl;
    for (int nivel = 0; nivel <= alto; nivel++){
        RecorridoAmplitudRecursivoSinCola(emisor.raiz,destino.raiz, nivel);
    }
//    cout << endl << "Recorrer desde las hojas hasta la raiz:" << endl;
//    for (int nivel = alto; 0 <= nivel; nivel--)
//        RecorridoAmplitudRecursivoSinCola(arbol.raiz, nivel);
}
void    fusionaArbolitos(ArbolBinario&destino,ArbolBinario&emisor){
    int numLotesDestino=calculaNodosEnArbol(destino.raiz);
    int numLotesEmisor=calculaNodosEnArbol(emisor.raiz);
    if(numLotesDestino>=numLotesEmisor){
        RecorridoAmplitudRecursivoSinCola(destino,emisor);
    }else{
        RecorridoAmplitudRecursivoSinCola(emisor,destino);
    }
}
int main(int argc, char** argv) {
    ifstream archDestino("archivoDestino.txt",ios::in);
    ifstream archEmisor("archivoEmisor.txt",ios::in);
    ArbolBinarioBusqueda emisor, destino;
    construir(emisor);
    construir(destino);
    int fecha,stock;
    char c;
    while(true){
        archDestino>>fecha;
        if(archDestino.eof())break;
        archDestino>>c>>stock;
        archDestino.get();
        insertarDatosEnArbolBB(destino.arbolBinario.raiz,fecha,stock);
    }
    while(true){
        archEmisor>>fecha;
        if(archEmisor.eof())break;
        archEmisor>>c>>stock;
        insertarDatosEnArbolBB(emisor.arbolBinario.raiz,fecha,stock);
    }
    cout<<"DESTINO: "<<endl;
    imprimeEnOrdenBB(destino.arbolBinario.raiz);
    cout<<endl;
    cout<<"EMISOR: "<<endl;
    imprimeEnOrdenBB(emisor.arbolBinario.raiz);
    cout<<endl;
    fusionaArbolitos(destino.arbolBinario,emisor.arbolBinario);
    imprimeEnOrdenBB(destino.arbolBinario.raiz);
    return 0;
}


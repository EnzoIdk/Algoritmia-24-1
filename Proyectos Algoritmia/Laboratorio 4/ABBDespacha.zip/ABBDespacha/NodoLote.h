/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NodoLote.h
 * Author: cueva
 *
 * Created on 26 de mayo de 2024, 07:26 PM
 */

#ifndef NODOLOTE_H
#define NODOLOTE_H
struct NodoLote{
    int lote;
    int cantidad;
};


#endif /* NODOLOTE_H */


/*
 * Proyecto : PreguntaHuaman-PredictMikler
 * Archivo  : main.cpp
 * Autor    : Alex Calero Revilla
 * Codigo   : 20206455
 * Fecha    : 4 de julio de 2024, 16:34
 */

#include <iostream>
#define V 9
#define DEFAULT 9999
#define DEFAULTV2 -9999
using namespace std;

int hallarMinimaDistancia(int latencias[], bool visitados[]) {
	int servidor, minimo = DEFAULT;
	for(int i = 0; i < V; i++) {
		if(!visitados[i] && latencias[i] <= minimo) {
			minimo = latencias[i];
			servidor = i;
		}
	}
	return servidor;
}

void dijkstra(int servidores[V][V], int servidorInicial) {
	int latencias[V];
	bool visitados[V];
	for(int i = 0; i < V; i++) {
		latencias[i] = DEFAULT;
		visitados[i] = false;
	}

	latencias[servidorInicial] = 0;
	for(int i = 0; i < V; i++) {
		int servidor = hallarMinimaDistancia(latencias, visitados);
		visitados[servidor] = true;
		for(int j = 0; j < V; j++) {
			if(!visitados[j] && servidores[servidor][j] && latencias[servidor] != DEFAULT &&
			   (latencias[servidor] + servidores[servidor][j]) < latencias[j])
				latencias[j] = latencias[servidor] + servidores[servidor][j];
		}
	}

	char letra = 'A';
	for(int i = 0; i < V; i++) {
		cout << "Servidor " << letra << ": " << latencias[i] << endl;
		letra++;
	}
}

int hallarMaximaDistancia(int latencias[], bool visitados[]) {
	int servidor, maximo = DEFAULTV2;
	for(int i = 0; i < V; i++) {
		if(!visitados[i] && latencias[i] >= maximo) {
			maximo = latencias[i];
			servidor = i;
		}
	}
	return servidor;
}

void dijkstraV2(int servidores[V][V], int servidorInicial) {
	int latencias[V];
	bool visitados[V];
	for(int i = 0; i < V; i++) {
		latencias[i] = DEFAULTV2;
		visitados[i] = false;
	}

	latencias[servidorInicial] = 0;
	for(int i = 0; i < V; i++) {
		int servidor = hallarMaximaDistancia(latencias, visitados);
		visitados[servidor] = true;
		for(int j = 0; j < V; j++) {
			if(!visitados[j] && servidores[servidor][j] && latencias[servidor] != DEFAULT &&
			   (latencias[servidor] + servidores[servidor][j]) > latencias[j])
				latencias[j] = latencias[servidor] + servidores[servidor][j];
		}
	}

	char letra = 'A';
	for(int i = 0; i < V; i++) {
		cout << "Servidor " << letra << ": " << latencias[i] << endl;
		letra++;
	}
}

int main(int argc, char** argv) {
	int servidores[V][V] = {
	  // A, B, C, D, E, F, G, H, I
		{0, 5, 0, 0, 0, 0, 4, 0, 6},
		{5, 0, 7, 0, 0, 0, 0, 5, 3},
		{0, 7, 0, 4, 0, 0, 0, 1, 0},
		{0, 0, 4, 0, 3, 0, 0, 6, 0},
		{0, 0, 0, 3, 0, 5, 0, 4, 0},
		{0, 0, 0, 0, 5, 0, 1, 5, 0},
		{4, 0, 0, 0, 0, 1, 0, 3, 5},
		{0, 5, 1, 6, 4, 5, 3, 0, 2},
		{6, 3, 0, 0, 0, 0, 5, 2, 0}
	};

	cout << "HALLAR LAS MINIMAS LATENCIAS:\n";
	dijkstra(servidores, 0);

	cout << "\nHALLAR LAS MAXIMAS LATENCIAS:\n";
	dijkstraV2(servidores, 0);

	return 0;
}

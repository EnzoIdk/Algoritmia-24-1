/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 2 de julio de 2024, 15:59
 */

#include <iostream>
#include <iomanip>
#include <climits>//limits.h
#include "Cola.h"
#include "Pila.h"
#include "funcionesCola.h"
#include "funcionesPila.h"
using namespace std;
#define V 5

void BFS(int grafo[V][V],int verticeIni){
    //Creacion de variables/estructuras auxiliares
    struct Cola cola;
    construir(cola);
    bool visitado[V];
    
    //Inicializar
    for(int i=0;i<V;i++)visitado[i]=false;
    encolar(cola,verticeIni);
    visitado[verticeIni]=true;
    
    //Recorrer
    while(!esColaVacia(cola)){
        int actual=desencolar(cola);
        
        //Operar (en este caso solo impresion)
        cout<<actual<<" ";
        
        //Recorrer adyacentes
        for(int i=0;i<V;i++){
            //Si no es visitado y tiene relacion
            if(!visitado[i] and grafo[actual][i]){
                //Se agrega a la cola
                encolar(cola,i);
                //Se marca como visitado
                visitado[i]=true;
            }
        }
    }
}
void DFS(int grafo[V][V],int verticeIni){
    //Creacion de variables/estructuras auxiliares
    struct Pila pila;
    construir(pila);
    bool visitado[V];
    
    //Inicializar
    for(int i=0;i<V;i++)visitado[i]=false;
    apilar(pila,verticeIni);
    visitado[verticeIni]=true;
    
    //Recorrer
    while(!esPilaVacia(pila)){
        int actual=desapilar(pila);
        
        //Operar (en este caso solo impresion)
        cout<<actual<<" ";
        
        //Recorrer adyacentes
        for(int i=0;i<V;i++){//otra forma (invertida): for(int i=V-1;i>0;i--)
            //Si no es visitado y tiene relacion
            if(!visitado[i] and grafo[actual][i]){
                //Se agrega a la cola
                apilar(pila,i);
                //Se marca como visitado
                visitado[i]=true;
            }
        }
    }
}
int hallarIndiceMinDist(int distancias[V], bool visitado[V]){
    //Variables auxiliares
    int minDist=INT_MAX,indice;
    
    //Busca el indice donde este la menor distancia
    //(siempre que no este visitado)
    for(int i=0;i<V;i++)
        if(!visitado[i] and distancias[i]<=minDist){
            minDist=distancias[i];
            indice=i;
        }
    
    //Regresa el indice
    return indice;
}
void mostrarDistancias(int distancias[V]){
    for(int i=0;i<V;i++)cout<<i<<": "<<distancias[i]<<endl;
}
void dijkstra(int grafo[V][V],int origen){
    //Creacion de variables/estructuras auxiliares
    int distancias[V];
    bool visitado[V];
    
    //Inicializar
    for(int i=0;i<V;i++){
        distancias[i]=INT_MAX;
        visitado[i]=false;
    }
    
    //Inicializar origen
    distancias[origen]=0;
    
    //Recorrer hasta un valor menos, pues ya se actualizo una distancia (origen)
    for(int vertice=0;vertice<V-1;vertice++){
        //Encontrar el indice donde esta la menor distancia sin visitar
        //(en la primera iteracion toma el origen, pues sera el menor)
        int indiceMinDist=hallarIndiceMinDist(distancias,visitado);
        
        //Actualizar visitado
        visitado[indiceMinDist]=true;
        
        //Recorrer todos los vertices
        for(int i=0;i<V;i++){
            //Actualizar distancias de todos los vertices...
            if( //que no esten visitados
                !visitado[i] and
                //tengan distancia diferente a INT_MAX
                distancias[indiceMinDist]!=INT_MAX and
                //tengan relacion (es decir, sean adyacentes)
                grafo[indiceMinDist][i] and
                //tengan una suma de distancias menor a la distancia menor
                distancias[indiceMinDist]+grafo[indiceMinDist][i]<distancias[i]
                    )
                distancias[i]=distancias[indiceMinDist]+grafo[indiceMinDist][i];
        }
    }
    
    //La respuesta se encontrara en distancias[V]
    mostrarDistancias(distancias);
}
int main(int argc, char** argv) {
    int grafo[V][V]={{0,3,0,7,0},//Representaci�n del Grafo: Matriz de Adyacencia
                    {3,0,4,2,0},
                    {0,4,0,5,6},
                    {7,2,5,0,4},
                    {0,0,6,4,0}};
    /**************************************************************************/
    /**************************************************************************/
    cout<<"Recorrido BFS:"<<endl;
    BFS(grafo,0);
    cout<<endl;
    /**************************************************************************/
    /**************************************************************************/
    cout<<"Recorrido DFS:"<<endl;
    DFS(grafo,0);
    cout<<endl;
    /**************************************************************************/
    /**************************************************************************/
    cout<<"Camino mas Corto (Dijkstra):"<<endl;
    int origen=0;
    dijkstra(grafo,origen);
    /**************************************************************************/
    /**************************************************************************/
    return 0;
}


// -*- C++ -*-

/* 
 * File:   Nodo.h
 * Author: ANA RONCAL
 *
 * Created on 4 de julio de 2024, 10:59
 */

#ifndef NODO_H
#define NODO_H

struct Nodo{
    int elemento;
    struct Nodo * siguiente;
};

#endif /* NODO_H */
/* 
 * File:   Cola.h
 * Author: ANA RONCAL
 * Created on 12 de septiembre de 2023, 09:32 PM
 */

#ifndef COLA_H
#define COLA_H

struct Cola{
    struct Lista lista;
};

#endif /* COLA_H */


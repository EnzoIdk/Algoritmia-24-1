/* 
 * File:   Cola.h
 * Author: ANA RONCAL
 * Created on 18 de abril de 2024, 10:21 AM
 */

#ifndef COLA_H
#define COLA_H

#include "Lista.h"
struct Cola {
    struct Lista lista;
};


#endif /* COLA_H */


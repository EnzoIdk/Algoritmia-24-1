/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Partido.h
 * Author: Enzo
 *
 * Created on 3 de julio de 2024, 09:39 PM
 */

#ifndef PARTIDO_H
#define PARTIDO_H

struct Partido{
    char local[15];
    int golesLocal;
    char visitante[15];
    int golesVisitante;
};

#endif /* PARTIDO_H */


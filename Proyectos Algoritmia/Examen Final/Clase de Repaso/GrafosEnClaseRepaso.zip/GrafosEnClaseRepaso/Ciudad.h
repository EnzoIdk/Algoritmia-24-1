// -*- C++ -*-

/* 
 * File:   Ciudad.h
 * Author: ANA RONCAL
 *
 * Created on 26 de junio de 2024, 17:58
 */

#ifndef CIUDAD_H
#define CIUDAD_H

struct Ciudad{
    char elemento;
    double ponderado;
};

#endif /* CIUDAD_H */
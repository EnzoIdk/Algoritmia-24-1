// -*- C++ -*-

/* 
 * File:   NodoArista.h
 * Author: ANA RONCAL
 *
 * Created on 20 de junio de 2024, 12:49
 */

#ifndef NODOARISTA_H
#define NODOARISTA_H

struct NodoArista {
    char elemento;    //ElementoListaArista: ACÁ PUEDE CAMBIAR EL ELEMENTO
    double ponderado;    //para Grafos ponderados
    struct NodoArista * siguiente;
} ;

#endif /* NODOARISTA_H */
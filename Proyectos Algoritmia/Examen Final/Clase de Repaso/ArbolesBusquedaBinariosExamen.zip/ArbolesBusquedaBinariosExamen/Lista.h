/* 
 * File:   Lista.h
 * Author: ANA RONCAL
 * Created on 8 de octubre de 2023, 05:44 PM
 */

#ifndef LISTA_H
#define LISTA_H

struct Lista{
    struct NodoPuntaje * cabeza; /*apunta al inicio de la lista*/
    int longitud; /*guarda la longitud de la lista*/
};

#endif /* LISTA_H */


/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 24 de junio de 2024, 10:23 AM
 */

#include <iostream>
using namespace std;
#include <climits>

#define V 5

/*
 * Clase 24/06:
 * Final: 
 * Grafo de 5ptos - Huamán (Se puede usar matriz de adyacencia) (Opc:Lista)
 * ABB - Intensamente - Allasi
 * No considerar la complejidad en archivo de texto.
 * 
 * P1: Pixar y sus amigos - ABB (10 puntos) - Allasi
 * P2: Pila + Complejidad (10 puntos) - Cueva
 * P3:
 *     a) Grafo seguro (5 puntos) - Huamán (Ya la mandó)
 *     b) Por definir (5 puntos) - Roncal (Posible DyV)
 * 
 */

int rutaMinimaRec(int grafo[V][V], int ini, int fin){
    //CASI FIN
    if(ini==fin) return 0;
    //VARIABLES
    int minDist=INT_MAX, temp;
    //ITERACION Y RECURSION
    for(int i=ini+1; i<=fin; i++){
        if(grafo[ini][i]!=0) temp=grafo[ini][i]+rutaMinimaRec(grafo, i, fin);
        if(temp<minDist) minDist=temp;
    }
    return minDist;
}

void imprimeSolucion(int * distancia){
    for(int i=0; i<V; i++){
        cout<<(char)(i+'a')<<" -> "<<distancia[i]<<endl;
    }
}

int minimaDistancia(int * distancia, bool * visitado){
    int nodoMin, temp=INT_MAX;
    
    for(int i=0; i<V; i++){
        if(not visitado[i] and distancia[i]<=temp){
            temp=distancia[i];
            nodoMin=i;
        }
    }
    
    return nodoMin;
}

void dijkstra(int grafo[V][V], int inic){
    //UN ARREGLO PARA
    int distancia[V], temp;
    bool visitado[V];
    //INICIALIZACION
    for(int i=0; i<V; i++){
        distancia[i]=INT_MAX;
        visitado[i]=false;
    }
    distancia[inic]=0;
    
    //UNA BUSQUEDA PARA CADA UNO DE LOS NODOS
    for(int i=0; i<V-1; i++){
        //HALLAMOS EL NODO CON LA MINIMA DISTANCIA
        temp=minimaDistancia(distancia, visitado);
        visitado[temp]=true;
        //DESDE EL NODO ENCONTRADO, SE HARA UNA BUSQUEDA A CADA OTRO NODO
        for(int j=0; j<V; j++){
            if(not visitado[j] and grafo[temp][j] and distancia[temp]!=INT_MAX 
                    and distancia[temp]+grafo[temp][j]<distancia[j])
                distancia[j]=distancia[temp]+grafo[temp][j];
        }
    }
    
    imprimeSolucion(distancia);
}

int maximaDistancia(int * distancia, bool * visitado){
    int nodoMin, temp=-1;
    
    for(int i=0; i<V; i++){
        if(not visitado[i] and distancia[i]>=temp){
            temp=distancia[i];
            nodoMin=i;
        }
    }
    
    return nodoMin;
}

void antiDijkstra(int grafo[V][V], int inic){
    //UN ARREGLO PARA
    int distancia[V], temp;
    bool visitado[V];
    //INICIALIZACION
    for(int i=0; i<V; i++){
        distancia[i]=-1;
        visitado[i]=false;
    }
    distancia[inic]=0;
    
    //UNA BUSQUEDA PARA CADA UNO DE LOS NODOS
    for(int i=0; i<V-1; i++){
        //HALLAMOS EL NODO CON LA MINIMA DISTANCIA
        temp=maximaDistancia(distancia, visitado);
        visitado[temp]=false;
        //DESDE EL NODO ENCONTRADO, SE HARA UNA BUSQUEDA A CADA OTRO NODO
        for(int j=0; j<V; j++){
            if(not visitado[j] and grafo[temp][j] and distancia[temp]!=-1 
                    and distancia[temp]+grafo[temp][j]>distancia[j])
                distancia[j]=distancia[temp]+grafo[temp][j];
        }
    }
    
    imprimeSolucion(distancia);
}

int main(int argc, char** argv) {
    //SI ES UN DIRIGIDO: Poner 0 
    
    //ESTE ES UN GRAFO NO DIRIGIDO
    int grafo[V][V]={
       //a, b, c, d, e
        {0, 3, 0, 7, 0}, //a
        {3, 0, 4, 2, 0}, //b
        {0, 4, 0, 5, 6}, //c
        {7, 2, 5, 0, 4}, //d
        {0, 0, 6, 4, 0}  //e
    };
    
    //RECURSIVO
    cout<<"Ruta minima recursiva: "<<rutaMinimaRec(grafo, 0, V-1)<<endl;
    
    //DIJKSTRA
    cout<<"Ruta minima a cada nodo desde un nodo dado (Dijkstra): "<<endl;
    dijkstra(grafo, 0);
    cout<<"Ruta maxima a cada nodo desde un nodo dado (Dijkstra): "<<endl;
    antiDijkstra(grafo, 0);
    
    return 0;
}


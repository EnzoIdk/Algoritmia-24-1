/*
 *  Intento de Lucas Mattias Alvites Galarza - 20221943
 */

/* 
 * File:   NodoLetra.h
 * Author: Lucas
 *
 * Created on 3 de julio de 2024, 12:20 p.m.
 */

#ifndef NODOLETRA_H
#define NODOLETRA_H

struct NodoLetra{
    char letra;
    int orden;
};


#endif /* NODOLETRA_H */


/* 
 * File:   funcionesGrafo.cpp
 * Author: Ana Roncal
 * 
 * Created on 18 de junio de 2024, 16:03
 */
#include <iostream>
#include <vector>
#include <map>
#include "Grafo.h"
using namespace std;

//
//Grafo::Grafo(int ver) {
//    lista.resize(ver);
//}
//
//void Grafo::agregarArista(int u, int v) {
//    lista[u].push_back(v);
//    lista[v].push_back(u); // Para grafos no dirigidos
//}
//
//void Grafo::imprimirGrafo() {
//    for (int i = 0; i < lista.size(); i++) {
//        cout << i << "-> ";
//        for (int j = 0; j < lista[i].size(); j++) {
//            cout << lista[i][j] << " ";
//        }
//        cout << endl;
//    }
//}


//Si se necesita realizar entre caracteres se usa el map

Grafo::Grafo() {
}

void Grafo::agregarVerticeMap(char ver) {
    if (listaMap.find(ver) == listaMap.end()) { //añade el vector si no se encuentra
        listaMap[ver] = vector<char>();
    }
}

void Grafo::agregarAristaMap(char u, char v) {
    agregarVerticeMap(u);
    agregarVerticeMap(v);
    //OJOO///
    //tener en cuenta que si ya existe la arista no la debe añadir
    listaMap[u].push_back(v);
    // listaMap[v].push_back(u); // Para grafos no dirigidos
}

void Grafo::imprimirGrafoMap() {
    for (const auto & vertice : listaMap) {
        char cuidad = vertice.first;
        cout << "Ciudad " << cuidad << ": ";
        const vector<char> & adyacentes = vertice.second;
        for (char arista : adyacentes) {
            cout << arista << " ";
        }
        cout << endl;
    }
}
 
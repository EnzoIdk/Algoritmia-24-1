/* 
 * File:   main.cpp
 * Author: Ana Roncal
 *
 * Created on 18 de junio de 2024, 14:25
 */

#include <iostream>
#include <vector>
#include <map>
using namespace std;
#include "Grafo.h"

int main(int argc, char** argv) {
    
    // Crear un grafo con 5 nodos
//    Grafo grafo(4);
//    
//    // Añadir aristas
//    grafo.agregarArista(1, 2);
//    grafo.agregarArista(1, 3);
//    grafo.agregarArista(2, 3);
//    
//    // Mostrar el grafo
//    grafo.imprimirGrafo();
//    
    
    Grafo grafoMap;
    
    grafoMap.agregarVerticeMap('A');
    grafoMap.agregarVerticeMap('B');
    grafoMap.agregarVerticeMap('C');
    grafoMap.agregarAristaMap('A', 'B');
    grafoMap.agregarAristaMap('C', 'B');
    grafoMap.agregarAristaMap('C', 'A');
    grafoMap.agregarAristaMap('A', 'C');
    // Mostrar el grafo
    grafoMap.imprimirGrafoMap();
    
    return 0;
}
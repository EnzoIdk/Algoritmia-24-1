// -*- C++ -*-

/* 
 * File:   Grafo.h
 * Author: ANA RONCAL
 *
 * Created on 18 de junio de 2024, 14:52
 */

#ifndef GRAFO_H
#define GRAFO_H
using namespace std;

//class Grafo {
//    private:
//        vector< vector<int> > lista;
//    public:
//        // Constructor
//        Grafo(int ver);
//       
//        void agregarArista(int u, int v);
//
//        // Mostrar el grafo
//        void imprimirGrafo();
//};

class Grafo {
    private:
        map <char, vector<char> > listaMap;
    public:
        //Constructor
        Grafo();
        void agregarVerticeMap(char ver);
        void agregarAristaMap(char u, char v);

        // Mostrar el grafo
        void imprimirGrafoMap();
};

#endif /* GRAFO_H */
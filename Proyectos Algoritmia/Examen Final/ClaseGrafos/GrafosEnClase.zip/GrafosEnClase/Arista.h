// -*- C++ -*-

/* 
 * File:   Arista.h
 * Author: ANA RONCAL
 *
 * Created on 20 de junio de 2024, 12:50
 */

#ifndef ARISTA_H
#define ARISTA_H

#include "NodoArista.h"
struct Arista{
    struct NodoArista * cabeza;
    int longitud;
};

#endif /* ARISTA_H */
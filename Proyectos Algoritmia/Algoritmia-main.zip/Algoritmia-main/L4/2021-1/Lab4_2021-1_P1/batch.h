/*
 Definición de batch
*/
#ifndef BATCH_H
#define BATCH_H

typedef struct batch {
    int id;
    int quantity;
} ElementoArbol;


#endif

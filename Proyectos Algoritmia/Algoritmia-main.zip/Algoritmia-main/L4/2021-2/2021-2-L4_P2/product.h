/*
 Definición de Product
*/
#ifndef BATCH_H
#define BATCH_H

typedef struct Product  {
    char name;
    int price;
} ElementoArbol;


#endif


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Gandy Margoreth Zinanyuca Huillca
 *
 * Created on 21 de abril de 2024, 18:54
 */

#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include "Cola.h"
#include "Lista.h"
#include "Pila.h"
using namespace std;
#include "funcionesCola.h"
#include "funcionesLista.h"
#include "funcionesPila.h"
/*
 * 
 */
int main(int argc, char** argv) {

    struct Cola cola;
    construir(cola);
     
//    encolar(cola, 1, 'V');
//    encolar(cola, 2, 'V');
    
//    encolar(cola, 4, 'V');
//    encolar(cola, 5, 'C');
//    encolar(cola, 4, 'C');
////    encolar(cola, 3, 'C');
////    encolar(cola,3, 'V');
    
    encolar(cola,2, 'V');
    encolar(cola,1, 'V');
    encolar(cola,3, 'L');
    encolar(cola,2, 'L');
//    encolar(cola,1, 'L');
//    encolar(cola, 3, 'C');
//    encolar(cola, 2, 'C');
//    encolar(cola, 1, 'C');
    encolar(cola,10, 'V');
    imprime(cola);
    return 0;
}

 
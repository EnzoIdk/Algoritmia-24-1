/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 19 de abril de 2024, 12:13 PM
 */

#include <iostream>
using namespace std;

#include "Pila.h"
#include "funcionesPila.h"
#include "funcionesLista.h"

void pasarAUnaPila(struct Pila &robotKupa1, struct Pila &robotKupa2){
    int longitudPila2=longitud(robotKupa2), aux;
    for(int i=0; i<longitudPila2; i++){
        aux=desapilar(robotKupa2);
        apilar(robotKupa1, aux);
    }
}

void ordenarPila(struct Pila &pila, struct Pila &auxPila, int longit){
    if(longit==1) return;
    int aux, mayor, lAux;
    mayor=desapilar(pila);
    for(int i=0; i<longit-1; i++){
        aux=desapilar(pila);
        if(aux>mayor){
            apilar(auxPila, mayor);
            mayor=aux;
        }
        else apilar(auxPila, aux);
    }
    apilar(pila, mayor);
    lAux=longitud(auxPila);
    for(int i=0; i<lAux; i++){
        apilar(pila, desapilar(auxPila));
    }
    ordenarPila(pila, auxPila, longit-1);
}

void pasarEnOrden(struct Pila &robotKupa1, struct Pila &robotEnMundoChampinon, 
        int longit){
    if(longit==0) return;
    int ultimo;
    for(int i=0; i<longit-1; i++){
        apilar(robotEnMundoChampinon, desapilar(robotKupa1));
    }
    ultimo=desapilar(robotKupa1);
    for(int i=0; i<longit-1; i++){
        apilar(robotKupa1, desapilar(robotEnMundoChampinon));
    }
    apilar(robotEnMundoChampinon, ultimo);
    pasarEnOrden(robotKupa1, robotEnMundoChampinon, longit-1);
}

int main(int argc, char** argv) {
    
    struct Pila robotKupa1{};
    struct Pila robotKupa2{};
    struct Pila robotEnMundoChampinon{};
    
    construir(robotKupa1);
    construir(robotKupa2);
    construir(robotEnMundoChampinon);
    
    apilar(robotKupa1, 27);
    apilar(robotKupa1, 30);
    apilar(robotKupa1, 56);
    apilar(robotKupa1, 15);
    apilar(robotKupa1, 85);
    
    apilar(robotKupa2, 20);
    apilar(robotKupa2, 68);
    apilar(robotKupa2, 22);
    apilar(robotKupa2, 45);
    
    imprimir(robotKupa1);
    imprimir(robotKupa2);
    
    pasarAUnaPila(robotKupa1, robotKupa2);
    
    imprimir(robotKupa1);
    imprimir(robotKupa2);
    
    ordenarPila(robotKupa1, robotKupa2, longitud(robotKupa1));
    
    imprimir(robotKupa1);
    
    pasarEnOrden(robotKupa1, robotEnMundoChampinon, longitud(robotKupa1));
    
    imprimir(robotKupa1);
    imprimir(robotEnMundoChampinon);
    
    return 0;
}


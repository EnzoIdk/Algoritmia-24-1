// -*- C++ -*-

/* 
 * File:   ArbolBinarioBusqueda.h
 * Author: ANA RONCAL
 *
 * Created on 30 de mayo de 2024, 15:51
 */

#ifndef ARBOLBINARIOBUSQUEDA_H
#define ARBOLBINARIOBUSQUEDA_H
#include "ArbolBinario.h"
struct ArbolBinarioBusqueda{
    struct ArbolBinario arbolBinario;
};

#endif /* ARBOLBINARIOBUSQUEDA_H */
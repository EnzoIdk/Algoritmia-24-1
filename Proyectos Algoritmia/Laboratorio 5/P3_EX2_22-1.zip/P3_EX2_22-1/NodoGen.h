/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   NodoGen.h
 * Author: n421
 *
 * Created on 14 de junio de 2024, 01:44 PM
 */

#ifndef NODOGEN_H
#define NODOGEN_H

struct NodoGen{
    int id;
    char letra;
};

#endif /* NODOGEN_H */


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Arma.h
 * Author: alulab14
 *
 * Created on 13 de abril de 2024, 08:21 AM
 */

#ifndef ARMA_H
#define ARMA_H

struct Arma{
    char arma;
    int poder;
    int tipo;
    int numReq;
    char armasReq[3];
};

#endif /* ARMA_H */


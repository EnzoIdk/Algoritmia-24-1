/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Guerrero.h
 * Author: alulab14
 *
 * Created on 13 de abril de 2024, 08:07 AM
 */

#ifndef GUERRERO_H
#define GUERRERO_H

struct Guerrero{
    int poder;
    int numArmas;
    int tipoArma[3];
};

#endif /* GUERRERO_H */


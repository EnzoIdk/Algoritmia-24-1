/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Proyecto.h
 * Author: Enzo
 *
 * Created on 7 de abril de 2024, 06:19 PM
 */

#ifndef PROYECTO_H
#define PROYECTO_H

struct Proyecto{
    int costo;
    int ganancia;
    int numPred;
    int predecesores[5];
};

#endif /* PROYECTO_H */


/* 
 * File:   main.cpp
 * Author: Lucas
 *
 * Created on 6 de mayo de 2024, 17:45
 */

#include <iostream>

#include "Cola.h"
#include "funcionesCola.h"
#include "funcionesLista.h"
using namespace std;

/*
 * 
 */

void fusionarColas(struct Lista &lista1, struct Lista &lista2){
    if(esListaVacia(lista1)){
        if(not esListaVacia(lista2)){
            lista1.cabeza=lista2.cabeza;
            lista1.cola=lista2.cola;
        }
        return;
    }
    //PARA LA O(1)
    if(lista2.cabeza->elemento>=lista1.cola->elemento){
        lista1.cola->siguiente=lista2.cabeza;
        lista1.cola=lista2.cola;
    }
    else if(lista2.cola->elemento<=lista1.cabeza->elemento){
        lista2.cola->siguiente=lista1.cabeza;
        lista1.cabeza=lista2.cabeza;
    }
    else{
        struct Nodo * aux1=lista1.cabeza, * aux2=lista2.cabeza, * ini, * fin;
        //PRIMERA PASADA
        if(aux1->elemento>=aux2->elemento){
            ini=aux2;
            fin=aux2;
            lista2.cabeza=lista2.cabeza->siguiente;
        }
        else{
            ini=aux1;
            fin=aux1;
            lista1.cabeza=lista1.cabeza->siguiente;
        }
        //EN INTERACION
        while(true){
            aux1=lista1.cabeza;
            aux2=lista2.cabeza;
            if(aux1==nullptr or aux2==nullptr) break;
            if(aux1->elemento>=aux2->elemento){
                fin->siguiente=aux2;
                fin=aux2;
                lista2.cabeza=lista2.cabeza->siguiente;
            }
            else {
                fin->siguiente=aux1;
                fin=aux1;
                lista1.cabeza=lista1.cabeza->siguiente;
            }
        }
        if(not esListaVacia(lista1)){
            fin->siguiente=lista1.cabeza;
            fin=lista1.cola;
        }
        if(not esListaVacia(lista2)){
            fin->siguiente=lista2.cabeza;
            fin=lista2.cola;
        }
        lista1.cabeza=ini;
        lista1.cola=fin;
    }
}

int main(int argc, char** argv) {
    
    struct Cola cola1;
    struct Cola cola2;
    
    construir(cola1);
    construir(cola2);
    
    encolar(cola1, 12);
    encolar(cola1, 15);
    encolar(cola1, 243);
    
    encolar(cola2, 13);
    encolar(cola2, 16);
    encolar(cola2, 52);
    
    imprime(cola1);
    imprime(cola2);
    
    fusionarColas(cola1.lista, cola2.lista);
    
    imprime(cola1);
    
    return 0;
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Flota.h
 * Author: Enzo
 *
 * Created on 17 de mayo de 2024, 08:11 AM
 */

#ifndef BUS_H
#define BUS_H

#include "Lista.h"

struct Bus{
    struct Lista pesos;
    int pesoTotalBus;
};

#endif /* FLOTA_H */


/* 
 * File:   Cola.h
 * Author: ANA RONCAL
 * Created on 7 de abril de 2024, 06:05 PM
 */

#ifndef COLA_H
#define COLA_H

#include "Lista.h"
struct Cola{
    struct Lista lista;
};
#endif /* COLA_H */

